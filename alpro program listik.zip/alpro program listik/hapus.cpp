#include "alat.h"

void hapusData(vector<Alat> &data)
{
    if (data.empty())
    {
        cout << "Data masih kosong!\n";
        return;
    }

    int id;
    tampilkanData(data);
    cout << "\nPilih nomor alat yang ingin dihapus: ";
    cin >> id;

    if (id < 1 || id > data.size())
    {
        cout << "Nomor tidak valid!\n";
        return;
    }

    data.erase(data.begin() + (id - 1));
    cout << "Data berhasil dihapus!\n";
}
