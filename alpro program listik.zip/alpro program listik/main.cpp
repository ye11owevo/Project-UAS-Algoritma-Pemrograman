#include "alat.h"

void mainMenu()
{
    vector<Alat> data;
    int pilihan;

    do
    {
        cout << "\n========== PROGRAM PELACAK BIAYA & KONSUMSI LISTRIK ==========\n";
        cout << "1. Input Data Alat\n";
        cout << "2. Tampilkan Data\n";
        cout << "3. Hitung Total Biaya & Konsumsi\n";
        cout << "4. Urutkan Boros → Hemat (DESC)\n";
        cout << "5. Urutkan Hemat → Boros (ASC)\n";
        cout << "6. Edit Data\n";
        cout << "7. Hapus Data\n";
        cout << "0. Keluar\n";
        cout << "===============================================================\n";
        cout << "Pilih menu: ";
        cin >> pilihan;

        switch (pilihan)
        {
        case 1:
            inputDataAlat(data);
            break;
        case 2:
            tampilkanData(data);
            break;
        case 3:
            hitungTotal(data);
            break;
        case 4:
            sortingDesc(data);
            break;
        case 5:
            sortingAsc(data);
            break;
        case 6:
            editData(data);
            break;
        case 7:
            hapusData(data);
            break;
        case 0:
            cout << "Keluar program...\n";
            break;
        default:
            cout << "Pilihan tidak valid!\n";
        }
    } while (pilihan != 0);
}

int main()
{
    mainMenu();
    return 0;
}
