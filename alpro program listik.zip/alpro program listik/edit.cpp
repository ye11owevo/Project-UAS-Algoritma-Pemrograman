#include "alat.h"

void editData(vector<Alat> &data)
{
    if (data.empty())
    {
        cout << "Data masih kosong!\n";
        return;
    }

    int id;
    tampilkanData(data);
    cout << "\nPilih nomor alat yang ingin diedit: ";
    cin >> id;

    if (id < 1 || id > data.size())
    {
        cout << "Nomor tidak valid!\n";
        return;
    }

    id--;

    cout << "Nama baru: ";
    cin >> ws;
    getline(cin, data[id].nama);
    cout << "Daya baru (Watt): ";
    cin >> data[id].daya;
    cout << "Jam baru: ";
    cin >> data[id].jam;

    data[id].kwh = (data[id].daya * data[id].jam) / 1000.0;
    data[id].biaya = data[id].kwh * TARIF;

    cout << "\nData berhasil diperbarui!\n";
}
