#ifndef ALAT_H
#define ALAT_H

#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

struct Alat
{
    string nama;
    float daya;
    float jam;
    float kwh;
    float biaya;
};

extern const float TARIF;

void inputDataAlat(vector<Alat> &data);
void tampilkanData(const vector<Alat> &data);
void hitungTotal(const vector<Alat> &data);
void sortingAsc(vector<Alat> &data);
void sortingDesc(vector<Alat> &data);
void editData(vector<Alat> &data);
void hapusData(vector<Alat> &data);

#endif
