#include "alat.h"

void sortingDesc(vector<Alat> &data)
{
    for (int i = 0; i < data.size() - 1; i++)
    {
        for (int j = 0; j < data.size() - i - 1; j++)
        {
            if (data[j].kwh < data[j + 1].kwh)
            {
                swap(data[j], data[j + 1]);
            }
        }
    }
    cout << "\nData diurutkan (boros → hemat).\n";
}
