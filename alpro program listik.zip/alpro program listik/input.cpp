#include "alat.h"

const float TARIF = 1500;

void inputDataAlat(vector<Alat> &data)
{
    int n;
    cout << "Jumlah alat yang ingin dimasukkan: ";
    cin >> n;

    for (int i = 0; i < n; i++)
    {
        Alat a;
        cout << "\nAlat ke-" << i + 1 << endl;
        cout << "Nama alat: ";
        cin >> ws;
        getline(cin, a.nama);
        cout << "Daya (Watt): ";
        cin >> a.daya;
        cout << "Lama pemakaian (jam per hari): ";
        cin >> a.jam;

        a.kwh = (a.daya * a.jam) / 1000.0;
        a.biaya = a.kwh * TARIF;

        data.push_back(a);
    }
}
