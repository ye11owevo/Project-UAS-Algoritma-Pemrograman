#include "alat.h"

void hitungTotal(const vector<Alat> &data)
{
    float totalKwh = 0, totalBiaya = 0;

    for (auto &a : data)
    {
        totalKwh += a.kwh;
        totalBiaya += a.biaya;
    }

    cout << "\nTotal Konsumsi Listrik per Hari : " << totalKwh << " kWh";
    cout << "\nTotal Biaya Listrik per Hari    : Rp " << totalBiaya << endl;
}
