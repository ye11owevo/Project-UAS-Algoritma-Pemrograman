#include "alat.h"

void tampilkanData(const vector<Alat> &data)
{
    cout << "\n=====================================================================\n";
    cout << left << setw(5) << "No"
         << setw(20) << "Nama Alat"
         << setw(10) << "Watt"
         << setw(10) << "Jam"
         << setw(12) << "kWh/Hari"
         << setw(12) << "Biaya(Rp)"
         << endl;
    cout << "=====================================================================\n";

    for (int i = 0; i < data.size(); i++)
    {
        cout << left << setw(5) << i + 1
             << setw(20) << data[i].nama
             << setw(10) << data[i].daya
             << setw(10) << data[i].jam
             << setw(12) << fixed << setprecision(2) << data[i].kwh
             << setw(12) << fixed << setprecision(0) << data[i].biaya
             << endl;
    }
    cout << "=====================================================================\n";
}
